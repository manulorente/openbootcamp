
for i in range(1,100+1).__reversed__():
    print(i)