
# Create and open txt file
with open("Python_ej17.txt", "w") as f:
    # Write in file
    f.write("Hello World")
    # Close file
    f.close()

