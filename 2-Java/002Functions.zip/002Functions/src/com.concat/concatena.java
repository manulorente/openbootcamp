package com.concat;

public class concatena {
    public static void main(String[] args) {
        String [] names = {"John", "Mary", "Paul", "Jane"};

        for (String name : names) {
            System.out.print(name + " ");
        }

        System.out.println();
        
        }   
    
}
